import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const PhysicalInformation: React.FC = () => {
  const [formData, setFormData] = useState({
    height: '',
    weight: '',
    age: '',
    gender: '',
    activityLevel: '',
    healthConditions: [] as string[],
  });

  const navigate = useNavigate();

  const activityLevels = [
    { id: 'sedentary', label: 'Sedentary', description: 'Little to no Exercise' },
    { id: 'lightly-active', label: 'Lightly Active', description: '1-3 Days a week Exercise' },
    { id: 'moderately-active', label: 'Moderately Active', description: '3-5 Days a week Exercise' },
    { id: 'very-active', label: 'Very Active', description: '5-7 Days a week Exercise' },
  ];

  const healthConditions = [
    'High Blood Pressure',
    'Back Pain/Injury',
    'Joint Issues',
    'Heart Condition',
    'Asthma',
    'Diabetes',
    'None of the above',
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleGenderSelect = (gender: string) => {
    setFormData((prev) => ({ ...prev, gender }));
  };

  const handleActivitySelect = (level: string) => {
    setFormData((prev) => ({ ...prev, activityLevel: level }));
  };

  const handleHealthToggle = (condition: string) => {
    setFormData((prev) => {
      const conditions = prev.healthConditions.includes(condition)
        ? prev.healthConditions.filter((item) => item !== condition)
        : [...prev.healthConditions, condition];
      return { ...prev, healthConditions: conditions };
    });
  };

  const handleContinue = () => {
    console.log('Physical Information Submitted:', formData);
    if (formData.height && formData.weight && formData.age && formData.gender && formData.activityLevel) {
      navigate('/schedule-your-success');
    } else {
      alert('Please complete all required fields before continuing.');
    }
  };
  
  return (
    <div style={{ maxWidth: '800px', margin: 'auto', paddingTop: '10px', fontFamily: 'Arial, sans-serif', paddingLeft: '700px' }}>
      {/* Page Title */}
     <div style={{backgroundColor: '#B00020', borderBottom: '30px solid #B00020 '}}> 
      <h2 style={{ textAlign: 'center', marginBottom: '10px' }}>Physical Information</h2>
      <p style={{ textAlign: 'center', color: 'lightgrey', marginBottom: '30px' }}>
        Help us customize your fitness plan
      </p>
     </div>
      <div style={{backgroundColor: 'white'}}>
        {/* Physical Details */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginBottom: '30px' }}>
          <input
            type="text"
            name="height"
            placeholder="Height (in cm)"
            value={formData.height}
            onChange={handleInputChange}
            style={{ ...inputStyle, backgroundColor: '#f5f5f5', width: '90%', marginLeft: '20px', textAlign: 'center', marginTop: '10px'  }}
          />
          <input
            type="text"
            name="weight"
            placeholder="Weight (in lbs)"
            value={formData.weight}
            onChange={handleInputChange}
            style={{ ...inputStyle, backgroundColor: '#f5f5f5', width: '90%', textAlign: 'center',  marginTop: '10px'}}
          />
          <input
            type="text"
            name="age"
            placeholder="Age"
            value={formData.age}
            onChange={handleInputChange}
            style={{ ...inputStyle, backgroundColor: '#f5f5f5', width: '90%', marginLeft: '20px', textAlign: 'center' }}
          />
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <button
              type="button"
              onClick={() => handleGenderSelect('Male')}
              style={{
                ...buttonStyle,
                backgroundColor: formData.gender === 'Male' ? '#B00020' : '#f5f5f5',
                color: formData.gender === 'Male' ? '#fff' : '#000',
              }}
            >
              Male
            </button>
            <button
              type="button"
              onClick={() => handleGenderSelect('Female')}
              style={{
                ...buttonStyle, marginRight: '20px', 
                backgroundColor: formData.gender === 'Female' ? '#B00020' : '#f5f5f5',
                color: formData.gender === 'Female' ? '#fff' : '#000',
              }}
            >
              Female
            </button>
          </div>
        </div>

        {/* Daily Activity Level */}
        <h3 style={{ marginBottom: '20px', color: 'black', textAlign: 'left', marginLeft: '10px' }}>Daily Activity Level</h3>
        {activityLevels.map((level) => (
          <div
            key={level.id}
            onClick={() => handleActivitySelect(level.id)}
            style={{
              padding: '15px',
              marginBottom: '10px',
              border: `2px solid ${formData.activityLevel === level.id ? '#B00020' : '#ddd'}`,
              textAlign: 'center', 
              borderRadius: '10px',
              cursor: 'pointer',
              backgroundColor: formData.activityLevel === level.id ? '#fdecea' : '#fff',
              
            }}
          >
            <h4 style={{ margin: '0 0 5px 0', color: formData.activityLevel === level.id ? '#B00020' : '#000' }}>
              {level.label}
            </h4>
            <p style={{ margin: 0, color: '#666' }}>{level.description}</p>
          </div>
        ))}

        {/* Health Considerations */}
        <h3 style={{ margin: '30px 0 20px', color: 'black', textAlign: 'left', marginLeft: '10px' }}>Health Considerations</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '15px' }}>
          {healthConditions.map((condition) => (
            <div
              key={condition}
              onClick={() => handleHealthToggle(condition)}
              style={{
                padding: '10px 15px',
                border: `2px solid ${formData.healthConditions.includes(condition) ? '#B00020' : '#ddd'}`,
                borderRadius: '10px',
                cursor: 'pointer',
                backgroundColor: formData.healthConditions.includes(condition) ? '#fdecea' : '#fff',
                color: formData.healthConditions.includes(condition) ? 'black' : 'black',
                textAlign: 'center',
              }}
            >
              {condition}
            </div>
          ))}
        </div>

        {/* Warning Message */}
        <p style={{
          marginTop: '20px',
          padding: '15px',
          backgroundColor: '#fff3cd',
          border: '1px solid #ffeeba',
          borderRadius: '5px',
          color: '#856404',
          fontSize: '0.9rem',
        }}>
          ⚠️ If you have any health conditions, we recommend consulting with your healthcare provider before starting any new exercise program.
        </p>

        {/* Continue Button */}
        <button
          onClick={handleContinue}
          disabled={!formData.height || !formData.weight || !formData.age || !formData.gender || !formData.activityLevel}
          style={{
            display: 'block',
            width: '60%',
            padding: '15px',
            backgroundColor: formData.height && formData.weight && formData.age && formData.gender && formData.activityLevel ? '#B00020' : '#ccc',
            color: '#fff',
            border: 'none',
            borderRadius: '10px',
            cursor: formData.height && formData.weight && formData.age && formData.gender && formData.activityLevel ? 'pointer' : 'not-allowed',
            marginTop: '20px',
            marginLeft: '140px', 
            fontSize: '1rem',
          }}
        >
          Continue
        </button>
      </div> 
    </div>
  );
};

// Styles
const inputStyle: React.CSSProperties = {
  width: '100%',
  padding: '10px',
  border: '1px solid #ddd',
  borderRadius: '5px',
  fontSize: '1rem',
};

const buttonStyle: React.CSSProperties = {
  flex: 1,
  padding: '10px',
  border: '1px solid #ddd',
  borderRadius: '10px',
  fontSize: '1rem',
  cursor: 'pointer',
  textAlign: 'center',
};

export default PhysicalInformation;
