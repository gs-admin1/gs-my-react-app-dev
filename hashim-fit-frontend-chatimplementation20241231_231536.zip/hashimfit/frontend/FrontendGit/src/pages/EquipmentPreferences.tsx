import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const EquipmentPreferences: React.FC = () => {
  const [formData, setFormData] = useState({
    workoutLocation: '',
    equipment: [] as string[],
    workoutStyles: [] as string[],
    aiGuidance: false,
  });

  const navigate = useNavigate();

  const workoutLocations = [
    { id: 'home', label: 'Home Workouts', description: 'Exercise in the comfort of your home' },
    { id: 'gym', label: 'Gym Access', description: 'Full gym equipment available' },
    { id: 'hybrid', label: 'Hybrid Approach', description: 'Mix of home and gym workouts' },
  ];

  const equipmentOptions = [
    'No Equipment',
    'Resistance Bands',
    'Pull-up Bar',
    'Foam Roller',
    'Dumbbells',
    'Workout Bench',
    'KettleBells',
    'Yoga Mat',
  ];

  const workoutStyles = [
    'High-Intensity Intervals',
    'Strength Training',
    'Circuit Training',
    'Supersets',
    'Traditional Sets',
    'Time Based Workouts',
    'Progressive Overload',
    'Drop Sets',
  ];

  const handleLocationSelect = (location: string) => {
    setFormData((prev) => ({ ...prev, workoutLocation: location }));
  };

  const handleEquipmentToggle = (equipment: string) => {
    setFormData((prev) => {
      const updatedEquipment = prev.equipment.includes(equipment)
        ? prev.equipment.filter((item) => item !== equipment)
        : [...prev.equipment, equipment];
      return { ...prev, equipment: updatedEquipment };
    });
  };

  const handleStyleToggle = (style: string) => {
    setFormData((prev) => {
      const updatedStyles = prev.workoutStyles.includes(style)
        ? prev.workoutStyles.filter((item) => item !== style)
        : [...prev.workoutStyles, style];
      return { ...prev, workoutStyles: updatedStyles };
    });
  };

  const handleAiGuidanceToggle = () => {
    setFormData((prev) => ({ ...prev, aiGuidance: !prev.aiGuidance }));
  };

  const handleCompleteSetup = () => {
    console.log('Equipment Preferences Submitted:', formData);
    if (formData.workoutLocation && formData.equipment.length > 0 && formData.workoutStyles.length > 0) {
      navigate('/plan-ready');
    } else {
      alert('Please complete all fields before finishing.');
    }
  };

  return (
    <div style={{ maxWidth: '800px', margin: 'auto', paddingTop: '20px', fontFamily: 'Raleway, sans-serif' , paddingLeft: '700px'}}>
      {/* Page Title */}
     <div style={{backgroundColor: '#B00020', borderBottom: '30px solid #B00020'}}> 
      <h2 style={{ textAlign: 'center', fontSize: '1.8rem', marginBottom: '10px' }}>Customize Your Experience</h2>
      <p style={{ textAlign: 'center', fontSize: '1rem', marginBottom: '30px', color: 'lightgrey' }}>
        Let’s tailor your workouts to your preferences
      </p>
     </div> 

      {/* Workout Location */}
     <div style={{backgroundColor: 'white', borderTop: '20px solid white'}}> 
      <h3 style={{ fontSize: '1.2rem', marginBottom: '15px', color: 'black', marginLeft: '15px' }}>Where will you find your workouts?</h3>
      {workoutLocations.map((location) => (
        <div
          key={location.id}
          onClick={() => handleLocationSelect(location.id)}
          style={{
            padding: '15px',
            marginBottom: '10px',
            border: `2px solid ${formData.workoutLocation === location.id ? '#B00020' : '#ddd'}`,
            borderRadius: '10px',
            cursor: 'pointer',
            backgroundColor: formData.workoutLocation === location.id ? '#fdecea' : '#fff',
          }}
        >
          <h4 style={{ margin: '0 0 5px 0', color: formData.workoutLocation === location.id ? '#B00020' : '#000' }}>
            {location.label}
          </h4>
          <p style={{ margin: 0, color: '#666', fontSize: '0.9rem' }}>{location.description}</p>
        </div>
      ))}

      {/* Available Equipment */}
      <h3 style={{ fontSize: '1.2rem', marginBottom: '15px', color: 'black', marginLeft: '15px' }}>Available Equipment</h3>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '15px', marginBottom: '30px' }}>
        {equipmentOptions.map((equipment) => (
          <div
            key={equipment}
            onClick={() => handleEquipmentToggle(equipment)}
            style={{
              padding: '10px 15px',
              border: `2px solid ${formData.equipment.includes(equipment) ? '#B00020' : '#ddd'}`,
              borderRadius: '10px',
              cursor: 'pointer',
              backgroundColor: formData.equipment.includes(equipment) ? '#fdecea' : '#fff',
              color: formData.equipment.includes(equipment) ? 'black' : 'black',
              textAlign: 'center',
            }}
          >
            {equipment}
          </div>
        ))}
      </div>

      {/* Workout Style Preferences */}
      <h3 style={{ fontSize: '1.2rem', marginBottom: '15px' , color: 'black', marginLeft: '15px'}}>Workout Style Preferences</h3>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '15px', marginBottom: '30px' }}>
        {workoutStyles.map((style) => (
          <div
            key={style}
            onClick={() => handleStyleToggle(style)}
            style={{
              padding: '10px 15px',
              border: `2px solid ${formData.workoutStyles.includes(style) ? '#B00020' : '#ddd'}`,
              borderRadius: '10px',
              cursor: 'pointer',
              backgroundColor: formData.workoutStyles.includes(style) ? '#fdecea' : '#fff',
              color: formData.workoutStyles.includes(style) ? 'black' : 'black',
              textAlign: 'center',
            }}
          >
            {style}
          </div>
        ))}
      </div>

      {/* AI Form Guidance */}
      <div style={{ display: 'flex', alignItems: 'center', marginBottom: '30px' }}>
        <label style={{ marginRight: '10px', fontSize: '1rem', color: 'black', marginLeft: '20px' }}>AI Form Guidance</label>
        <input
          type="checkbox"
          checked={formData.aiGuidance}
          onChange={handleAiGuidanceToggle}
          style={{ transform: 'scale(1.5)' }}
        />
      </div>

      {/* Warning Message */}
      <p style={{
        marginTop: '20px',
        padding: '15px',
        backgroundColor: '#fff3cd',
        border: '1px solid #ffeeba',
        borderRadius: '5px',
        color: '#856404',
        fontSize: '0.9rem',
      }}>
        ⚠️ Don’t worry if you don’t have much equipment. We’ll provide bodyweight alternatives and help you progress with what you have available.
      </p>

      {/* Complete Setup Button */}
      <button
        onClick={handleCompleteSetup}
        disabled={!formData.workoutLocation || !formData.equipment.length || !formData.workoutStyles.length}
        style={{
          display: 'block',
          width: '100%',
          padding: '15px',
          backgroundColor: formData.workoutLocation && formData.equipment.length && formData.workoutStyles.length ? '#B00020' : '#ccc',
          color: '#fff',
          border: 'none',
          borderRadius: '5px',
          cursor: formData.workoutLocation && formData.equipment.length && formData.workoutStyles.length ? 'pointer' : 'not-allowed',
          marginTop: '20px',
          fontSize: '1rem',
        }}
      >
        Complete Setup →
      </button>
     </div> 
    </div>
  );
};

export default EquipmentPreferences;
